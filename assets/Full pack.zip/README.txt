Created by SkaldingDelight under Creative Commons

Please use this art in your games, projects and otherwise.
Distrubution is through itch.io, and modifications to this pack should not be posted.

Need custome art? Email me at SkaldingDelight@gmail.com